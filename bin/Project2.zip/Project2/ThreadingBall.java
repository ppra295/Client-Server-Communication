package Project2;

public class ThreadingBall 
{
public static void main(String[] args) 
{
new MyBallWindow();
}
}